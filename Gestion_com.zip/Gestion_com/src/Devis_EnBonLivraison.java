import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ControlerPack.ConnectionDataBase;
import ControlerPack.Document_venteModel;

import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JSeparator;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.StringTokenizer;
import java.awt.event.ActionEvent;

public class Devis_EnBonLivraison extends JFrame {

	private JPanel contentPane;
	private DefaultComboBoxModel<String> dcm;
	protected ResultSet rsrech;
	protected Document_venteModel mytablemodel;
	protected JTable table;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Devis_EnBonLivraison frame = new Devis_EnBonLivraison();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Devis_EnBonLivraison() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 738, 430);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 712, 93);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(354, 0, 0, 93);
		panel.add(separator);
		
		 
		 dcm = new DefaultComboBoxModel<String>();
			ResultSet rs=ConnectionDataBase.executeQuery("select * from client");
			
			try {
				while(rs.next())
				{dcm.addElement(rs.getInt(1)+" "+rs.getString("nom")+"   "+rs.getString("prenom"));
				
					
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 
			 comboBox = new JComboBox(dcm);
			comboBox.addActionListener(new ActionListener() {
				

				public void actionPerformed(ActionEvent e) {
					
					 StringTokenizer st = new StringTokenizer((String)comboBox.getSelectedItem(),"   ");  
				     String     id_client=st.nextToken();
					rsrech=ConnectionDataBase.executeQuery("select * from document_vente where type_doc= 'BL' and id_client= "+Integer.parseInt(id_client) );
					mytablemodel=new Document_venteModel(rsrech);
					table.setModel(mytablemodel);
				}
			});
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		comboBox.setBounds(109, 29, 217, 27);
		panel.add(comboBox);
		
		JLabel lblClient = new JLabel("Client");
		lblClient.setBounds(10, 29, 89, 27);
		panel.add(lblClient);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 115, 712, 252);
		contentPane.add(scrollPane);
	}
}
