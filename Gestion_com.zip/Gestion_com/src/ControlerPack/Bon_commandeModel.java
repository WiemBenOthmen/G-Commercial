package ControlerPack;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

import classPack.Article;
import classPack.Bon_Commande;
import classPack.Bon_livraison_vente;

public class Bon_commandeModel  extends AbstractTableModel{
	int nblig;
	private int id_bon_commande;
	private String reference ;
	private int id_bon_livraisonA;
	private int id_doc_achat ;
	Bon_Commande bc;
	private java.sql.ResultSetMetaData rsmd;
	ArrayList <Bon_Commande> data=new ArrayList<Bon_Commande>();
	public  Bon_commandeModel(ResultSet rs) {
		try
		{
			rsmd=rs.getMetaData();
			while(rs.next())
			{
				nblig++;
				id_bon_commande=rs.getInt(1);
				reference=rs.getString(2);
				id_doc_achat=rs.getInt(4);
				id_bon_livraisonA=rs.getInt(3);
				bc=new Bon_Commande(id_bon_commande, reference, id_bon_livraisonA, id_doc_achat);
				data.add(bc);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return nblig;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		try {
			return rsmd.getColumnCount();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}

	@Override
	public Object getValueAt(int l, int c) {
		// TODO Auto-generated method stub
		Bon_Commande bon_com=data.get(l);
		if(c==0)
			{return bon_com.getId_bon_commande();
		  }
			if(c==1)
			{return bon_com.getReference();	}
			
		   if(c==2)
			{return bon_com.getId_bon_livraisonA();}
		if(c==3)
			{return bon_com.getId_doc_achat();
		}
		
		return("erreur");
	}
	@Override
	public String getColumnName(int l) {
	
		try {
			return rsmd.getColumnName(l+1);
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
	}
	public void supprimerLigne(int l){
		try{
		int a=RechercheBYID(l);
	data.remove(a);
	nblig --;
    fireTableDataChanged();
		}catch(Exception e){}		
	}
	
	public void AjouterLigne(Bon_Commande f){
		data.add(f);
		nblig ++;
	    fireTableDataChanged();
			
		}
	public void ModifierLigne(Bon_Commande f)
	{int a=RechercheBYID(f.getId_bon_commande());
		data.set(a,f);
	fireTableDataChanged();
		
	}
	
	
	public int RechercheBYID(int id)
	{int i=0;
	Boolean b=false;
	while(i<data.size()&&(b==false))
	{
	if(data.get(i).getId_bon_commande()==id)
	{
	b=true;
	}	
	i++;
	}
			return i-1;
	}

}
