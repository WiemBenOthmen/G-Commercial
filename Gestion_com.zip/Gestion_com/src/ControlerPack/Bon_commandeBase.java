package ControlerPack;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import classPack.Bon_Commande;
import classPack.Bon_livraison_vente;

public class Bon_commandeBase {
public Bon_commandeModel mytablemodel;
	
	public Bon_commandeBase()
	{
		
		mytablemodel=new Bon_commandeModel(ConnectionDataBase.executeQuery("select * from Bon_commande"));

	}
	public boolean ajoutBon_commande(Bon_Commande f1)
	{String req="INSERT INTO `bon_commande`(`ref_bon_commande`,`id_doc_achat`) VALUES('"+f1.getReference()+"',"+f1.getId_doc_achat()+")";
	String rech="select max(`id_bon_commande`) from bon_commande where ref_bon_commande='"+f1.getReference()+"' and id_doc_vente="+f1.getId_bon_commande();

	try {
		ConnectionDataBase.executeUpdate(req);
		ResultSet rs=ConnectionDataBase.executeQuery(rech);
		rs.next();
		f1.setId_bon_commande(rs.getInt(1));
		mytablemodel.AjouterLigne(f1);
		
		} catch (HeadlessException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}

		return true;
	}
	public int ModifierBon_commande(Bon_Commande f1)
	{String req="update  bon_commande set `ref_bon_commande`='"+f1.getReference()+"',`id_doc_achat`="+f1.getId_doc_achat()+",`id_bon_livraisonA`="+f1.getId_bon_livraisonA()+" where`id_bon_commande`="+f1.getId_bon_commande();	
	 int x=ConnectionDataBase.executeUpdate(req);

	 if (x>0)
		 {System.out.println("Done MAJ");
	 mytablemodel.ModifierLigne(f1);
		 }else
		 System.out.println("Erreure MAJ");
	 return x;	
	}
	
	public ResultSet affiche()
	{ResultSet rs = null;
		rs=ConnectionDataBase.executeQuery("select * from bon_commande");

		return rs ;
	}
	public ResultSet rechercheByID(int id)
	{
		return ConnectionDataBase.executeQuery("select * from bon_commande where `id_bon_commande`="+id);
	}
	public ResultSet rechercheByReference(String s)
	{
		return ConnectionDataBase.executeQuery("select * from bon_commande where `ref_bon_commande`='"+s+"'");
	}
	
	public void supprimerBon_commande(int id)
	{String req="delete from bon_commande where `id_bon_commande`="+id;
		int a=ConnectionDataBase.executeUpdate(req);
		if(a<1)
			JOptionPane.showMessageDialog(null," Suppression echou�!","Erreur",JOptionPane.ERROR_MESSAGE);
		else
			mytablemodel.supprimerLigne(id);
	}


}
