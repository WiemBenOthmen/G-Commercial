import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import classPack.Client;
import classPack.Fournisseur;
import ControlerPack.ArticleBase;
import ControlerPack.ArticleModel;
import ControlerPack.ClientBase;
import ControlerPack.ConnectionDataBase;
import ControlerPack.FournisseurBase;
import ControlerPack.FournisseurModel;


public class FournisseurJInternelFrame extends JInternalFrame  implements MouseListener{
	private JTextField textField;
	private JTable table;
	FournisseurBase db_fournisseur=null;
	private JTextField textRecherche;
	private JComboBox<String> cb_Recherche;
	private String req,s;
	ResultSet rsrech;
	private FournisseurModel rechercheModel;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FournisseurJInternelFrame frame = new FournisseurJInternelFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public FournisseurJInternelFrame()  {
		
		setBounds(100, 100, 450, 300);
		// db_client=new ClientBase((ResultSet)ConnectionDataBase.executeQuery("select * from client"));
		setTitle("Fournisseur");
		db_fournisseur=new FournisseurBase();
		    this.setBorder(null);
			this.setResizable(true);
			this.setIconifiable(true);
			this.setClosable(true);
			this.setBounds(0, 0, 1198, 685);
			this.setVisible(true);
			
			this.getContentPane().setLayout(null);
			
			 cb_Recherche = new JComboBox<String>();
				cb_Recherche.setModel(new DefaultComboBoxModel(new String[] {"R�f�rence", "Raison socail","Adresse", "Ville","N�T�l�phone","Matricule Fiscale","N�reglement commercial"}));
				cb_Recherche.setBounds(21, 25, 133, 33);
				JPanel panel_2 = new JPanel();
				panel_2.setBorder(new TitledBorder(null, "Rechercher", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 191, 255)));
				panel_2.setBounds(10, 85, 1178, 81);
				this.getContentPane().add(panel_2);
				panel_2.setLayout(null);
				panel_2.add(cb_Recherche);
				textRecherche = new JTextField();
				textRecherche.addKeyListener(new KeyAdapter() {
					@Override
					public void keyReleased(KeyEvent e) {
						search();
					}
				});
				textRecherche.setBounds(232, 25, 255, 33);
				panel_2.add(textRecherche);
				textRecherche.setColumns(10);
			
				JButton btnRechercher = new JButton("");
				
				Image imgrecherche=new ImageIcon(this.getClass().getResource("/Recherche.png")).getImage();
				btnRechercher.setIcon(new ImageIcon(imgrecherche));
				btnRechercher.addActionListener(new ActionListener() {
					
					public void actionPerformed(ActionEvent e) {
						search();
					}
					});
				btnRechercher.setBounds(497, 25, 56, 33);
				panel_2.add(btnRechercher);
				
				JButton btnReturn = new JButton("");
				Image imgrefresh=new ImageIcon(this.getClass().getResource("/Refresh.png")).getImage();
				btnReturn.setIcon(new ImageIcon(imgrefresh));
				btnReturn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						
						db_fournisseur.mytablemodel=new FournisseurModel(ConnectionDataBase.executeQuery("select *from fournisseur"));
						table.setModel(db_fournisseur.mytablemodel);
					}
				});
				btnReturn.setBounds(179, 25, 45, 33);
				panel_2.add(btnReturn);
				
				
				
			
			
			table = new JTable();
			
			table.setModel(db_fournisseur.mytablemodel);
			table.addMouseListener(this);
			
			
			JScrollPane scrollPane = new JScrollPane(table);
			scrollPane.setBounds(10, 171, 1178, 476);
			
	getContentPane().add(scrollPane);
	JPanel panel = new JPanel();
	panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, Color.CYAN));
	panel.setBounds(10, 2, 1178, 81);
	getContentPane().add(panel);
	panel.setLayout(null);

	JButton bajout = new JButton("Ajouter");
	bajout.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			FournisseurAjout c=new FournisseurAjout(db_fournisseur);
			c.setVisible(true);
			
		}
	});
	bajout.setBounds(3, 3, 108, 74);
	panel.add(bajout);
	bajout.setBackground(SystemColor.controlHighlight);

	JButton bmodif = new JButton("Modifier");
    bmodif.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(table.isRowSelected(table.getSelectedRow()))
			{
				Fournisseur fr =db_fournisseur.getFournisseur((int)table.getModel().getValueAt(table.getSelectedRow(), 0));
			 FournisseurMoudifier fm=new FournisseurMoudifier(db_fournisseur,fr,table.getModel());
				fm.setVisible(true);
			}
			else
			{JOptionPane.showMessageDialog(null,"Il faut selectionner une ligne!","Erreur",JOptionPane.ERROR_MESSAGE);}
			
		}
	});
	bmodif.setBounds(108, 3, 108, 74);
	panel.add(bmodif);
	bmodif.setBackground(SystemColor.controlHighlight);

	JButton bsup = new JButton("Supprimer");
	bsup.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(table.isRowSelected(table.getSelectedRow()))
			{
				db_fournisseur.supprimerFourisseur((int)table.getModel().getValueAt(table.getSelectedRow(),0));
			}
			else
			{JOptionPane.showMessageDialog(null,"Il faut selectionner une ligne!","Erreur",JOptionPane.ERROR_MESSAGE);}
		}
		
	});



	bsup.setBounds(214, 3, 108, 74);
	panel.add(bsup);
	bsup.setBackground(SystemColor.controlHighlight);

		}

		@Override
		public void mouseClicked(MouseEvent e) {
			if (e.getClickCount() == 2){
				System.out.println(table.getSelectedRow());
				
				Fournisseur fr =db_fournisseur.getFournisseur((int)table.getModel().getValueAt(table.getSelectedRow(), 0));
				 FournisseurMoudifier fm=new FournisseurMoudifier(db_fournisseur,fr,table.getModel());
					fm.setVisible(true);
				
			}
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		public void search()
		{
			 s=textRecherche.getText();
				if(cb_Recherche.getSelectedItem().toString().equals("R�f�rence"))
				{ req = "select * from fournisseur where ref_fournisseur LIKE '%"+s+"%'";	
				}
				if(cb_Recherche.getSelectedItem().toString().equals("Raison socail"))
				{ req = "select * from fournisseur where raison_social LIKE '%"+s+"%'";
					
				}
				if(cb_Recherche.getSelectedItem().toString().equals("Adresse"))
				{ req = "select * from fournisseur where adresse LIKE '%"+s+"%'";
				}
				if(cb_Recherche.getSelectedItem().toString().equals("Ville"))
				{ req = "select * from fournisseur where  ville LIKE '%"+s+"%'";
				}
				if(cb_Recherche.getSelectedItem().toString().equals("N�T�l�phone"))
				{ req = "select * from fournisseur where  num_tel LIKE '%"+s+"%'";
				}
			
				if(cb_Recherche.getSelectedItem().toString().equals("Matricule Fiscale"))
				{ req = "select * from fournisseur where  matricule_fiscale LIKE '%"+s+"%'";
				}
				if(cb_Recherche.getSelectedItem().toString().equals("N�reglement commercial"))
				{ req = "select * from fournisseur where  num_reg_commercial LIKE '%"+s+"%'";
				}
				rsrech=ConnectionDataBase.executeQuery(req);
				rechercheModel=new FournisseurModel(rsrech);
				
				db_fournisseur.mytablemodel=rechercheModel;
				table.setModel(db_fournisseur.mytablemodel);
			
			
			
		
		}	

	}


