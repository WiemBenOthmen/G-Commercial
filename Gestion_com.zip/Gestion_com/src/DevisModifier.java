import java.awt.EventQueue;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ControlerPack.ArticleBase;
import ControlerPack.ConnectionDataBase;
import ControlerPack.Ligne_venteBase;
import classPack.Article;
import classPack.Devis;
import classPack.Ligne_vente;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DevisModifier extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Ligne_venteBase db_lignevente;
	private ResultSet rslignevente,rsnom,rsncin,rsprenom,rsdate;
	private ArticleBase db_article;
	private Article article;
	private JTextField textFieldNom;
	private JTextField textFieldPrenom;
	private JTextField textFieldCin;
	private JTextField textFieldDate;
	private String nom,prenom,ncin,date,reqnom,reqprenom,reqncin,reqdate;
	/* public Statement st;
	 public Connection con;
	 public ResultSet rs;*/

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public DevisModifier(Devis devis) {
		//ConnectionDataBase.loadDriver("com.mysql.jdbc.Driver");
		//ConnectionDataBase.connect("jdbc:mysql://localhost:3306/gestioncommercial","root","");
		setBounds(300, 100, 861, 436);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		db_lignevente=new Ligne_venteBase();
		db_article=new ArticleBase();

		//table=new JTable(db_lignevente.mytablemodel);
		
		/*try {
			Class.forName("com.mysql.jdbc.Driver");
		     con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/gestioncommercial","root","");
		    st =(Statement) con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/

	
		initialeJtable(devis);
		table=new JTable();
		table.setModel(db_lignevente.mytablemodel);
		JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 133, 825, 253);
		contentPane.add(scrollPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 191, 255)));
		panel.setBounds(10, 11, 825, 111);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 11, 621, 76);
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(2, 4, 20, 20));
		
		JLabel lblNomClient = new JLabel("Nom Client");
		panel_1.add(lblNomClient);
		
		textFieldNom = new JTextField();
		panel_1.add(textFieldNom);
		textFieldNom.setColumns(10);
		textFieldNom.setEditable(false);
		reqnom="SELECT client.nom FROM client,devis,document_vente WHERE devis.id_doc_vente=document_vente.id_documentV AND document_vente.id_client=client.id_client AND devis.id_devis="+devis.getId_devis();
		rsnom=ConnectionDataBase.executeQuery(reqnom);
		try {
			if(rsnom.next())
			{
				nom=rsnom.getString(1);
				textFieldNom.setText(nom);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel lblNcin = new JLabel("N\u00B0Cin Client");
		panel_1.add(lblNcin);
		
		textFieldCin = new JTextField();
		panel_1.add(textFieldCin);
		textFieldCin.setColumns(10);
		textFieldCin.setEnabled(false);
		reqncin="SELECT client.ncin FROM devis,document_vente,client WHERE devis.id_doc_vente=document_vente.id_documentV AND document_vente.id_client=client.id_client AND devis.id_devis="+devis.getId_devis();
		//reqncin="SELECT document_vente.date_documentV FROM document_vente,devis WHERE devis.id_doc_vente=document_vente.id_documentV AND devis.id_devis="+devis.getId_devis();
		rsncin=ConnectionDataBase.executeQuery(reqncin);
		try {
			if(rsncin.next())
			{
				ncin=rsncin.getString(1);
				textFieldCin.setText(ncin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel lblPrenomClient = new JLabel("Prenom Client");
		panel_1.add(lblPrenomClient);
		
		textFieldPrenom = new JTextField();
		panel_1.add(textFieldPrenom);
		textFieldPrenom.setColumns(10);
		textFieldPrenom.setEditable(false);
		
		reqprenom="SELECT client.prenom FROM client,devis,document_vente WHERE devis.id_doc_vente=document_vente.id_documentV AND document_vente.id_client=client.id_client AND devis.id_devis="+devis.getId_devis();
		rsprenom=ConnectionDataBase.executeQuery(reqprenom);
		try {
			if(rsprenom.next())
			{
				prenom=rsprenom.getString(1);
				textFieldPrenom.setText(prenom);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JLabel lblDateDevis = new JLabel("Date Devis");
		panel_1.add(lblDateDevis);
		
		textFieldDate = new JTextField();
		panel_1.add(textFieldDate);
		textFieldDate.setColumns(10);
		textFieldDate.setEditable(false);
		
		reqdate="SELECT document_vente.date_documentV FROM document_vente,devis WHERE devis.id_doc_vente=document_vente.id_documentV AND devis.id_devis="+devis.getId_devis();
		rsdate=ConnectionDataBase.executeQuery(reqdate);
		try {
			if(rsdate.next())
			{
				date=rsdate.getString(1);
				textFieldDate.setText(date);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JButton btnPasserBonLivraison = new JButton("Passer Bon Livraison");
		btnPasserBonLivraison.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnPasserBonLivraison.setBounds(641, 22, 174, 52);
		panel.add(btnPasserBonLivraison);
        
		
	}

	private void initialeJtable(Devis devis) {
		rslignevente=ConnectionDataBase.executeQuery("select * from ligne_vente where id_doc_vente= "+devis.getId_doc_vente());
		try {
			while(rslignevente.next())
			{  int a=rslignevente.getInt("id_article");
				//rs=st.executeQuery("SELECT * FROM `article` WHERE `id_article`="+a);
				//System.out.println("a="+a);
	//article= (Article) db_article.rechercheByID(rslignevente.getInt("id_article"));
		article =db_article.mytablemodel.getArticle(rslignevente.getInt("id_article"));
			// article=new Article(rslignevente.getInt("id_article"), "dl", "aaaaaaaaa",10,10,10,12,"codeAbarre",1,1);
				//if(rs.next())
			//	{
					//Article article=new Article(rslignevente.getInt("id_article"), "dl", "aaaaaaaaa",10,10,10,12,"codeAbarre",1,1);
			//	}
				Ligne_vente lignev=new Ligne_vente(rslignevente.getInt(1),rslignevente.getFloat(2),rslignevente.getFloat(3),rslignevente.getFloat(4),rslignevente.getInt(5),article);
				//Ligne_vente lignev=new Ligne_vente(0,1,0,article.getPrixTTc(),100,article);

				db_lignevente.mytablemodel.AjouterLigne(lignev);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}
}
