import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import java.awt.Color;

import javax.swing.JScrollBar;
import javax.swing.JTable;

import classPack.Bon_Commande;
import ControlerPack.Bon_commandeBase;
import ControlerPack.Bon_livraison_venteBase;
import ControlerPack.ConnectionDataBase;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class BonCommandeInternelFrame extends JInternalFrame {
	private JTable table;
	private Bon_commandeBase db_commande;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BonCommandeInternelFrame frame = new BonCommandeInternelFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public BonCommandeInternelFrame() {
		ConnectionDataBase.loadDriver("com.mysql.jdbc.Driver");
		ConnectionDataBase.connect("jdbc:mysql://localhost:3306/gestioncommercial","root","");
		setTitle("Bon Commande");
		db_commande=new Bon_commandeBase();

		setBounds(100, 100, 450, 300);
		this.setBorder(null);
		this.setResizable(true);
		this.setIconifiable(true);
		this.setClosable(true);
		this.setBounds(0, 0, 1198, 685);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Liste des Bon Commandes ", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(102, 205, 170)));
		panel.setBounds(59, 132, 1094, 460);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		
		table = new JTable();
		table.setModel(db_commande.mytablemodel);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 21, 1074, 428);
		panel.add(scrollPane);
		
		JButton btnPasserBonCommande = new JButton("Passer Bon Commande");
		btnPasserBonCommande.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnPasserBonCommande.setBackground(new Color(250, 250, 210));
		btnPasserBonCommande.setForeground(new Color(32, 178, 170));
		btnPasserBonCommande.setBounds(59, 49, 186, 46);
		getContentPane().add(btnPasserBonCommande);

	}
}
