import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import ControlerPack.ArticleModel;
import ControlerPack.ConnectionDataBase;
import ControlerPack.DevisBase;
import ControlerPack.DevisModel;

import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;

import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import java.awt.SystemColor;
import java.sql.ResultSet;

public class DevisInternelFrame extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DevisInternelFrame frame = new DevisInternelFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	private JTable table;
	private DevisBase db_devis;
	private JTextField textRecherche;
	private JComboBox<String> cb_Recherche;
	private String req,s;
	ResultSet rsrech;
	private DevisModel rechercheModel;

	/**
	 * Create the frame.
	 */
	public DevisInternelFrame() {
		db_devis=new DevisBase();
		setTitle("Devis");
		setBounds(100, 100, 450, 300);
		this.setBorder(null);
		this.setResizable(true);
		this.setIconifiable(true);
		this.setClosable(true);
		this.setBounds(0, 0, 1198, 685);
		getContentPane().setLayout(null);
		//recherche
		 cb_Recherche = new JComboBox<String>();
		 cb_Recherche.setModel(new DefaultComboBoxModel(new String[] {"R\u00E9ference", "Date", "Client"}));
		 cb_Recherche.setBounds(21, 25, 133, 33);
			
			JPanel panel_2 = new JPanel();
			panel_2.setBorder(new TitledBorder(null, "Rechercher", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 191, 255)));
			panel_2.setBounds(10, 104, 563, 81);
			this.getContentPane().add(panel_2);
			panel_2.setLayout(null);
			panel_2.add(cb_Recherche);
			textRecherche = new JTextField();
			textRecherche.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					search();
				}
			});
			textRecherche.setBounds(232, 25, 255, 33);
			panel_2.add(textRecherche);
			textRecherche.setColumns(10);
			
			JButton btnRechercher = new JButton("");
			
			Image imgrecherche=new ImageIcon(this.getClass().getResource("/Recherche.png")).getImage();
			btnRechercher.setIcon(new ImageIcon(imgrecherche));
			btnRechercher.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					search();
				}
				});
			btnRechercher.setBounds(497, 25, 56, 33);
			panel_2.add(btnRechercher);
			
			JButton btnReturn = new JButton("");
			Image imgrefresh=new ImageIcon(this.getClass().getResource("/Refresh.png")).getImage();
			btnReturn.setIcon(new ImageIcon(imgrefresh));
			btnReturn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					db_devis.mytablemodel=new DevisModel(ConnectionDataBase.executeQuery("SELECT * FROM `devis`"));
					table.setModel(db_devis.mytablemodel);
				
				}
			});
			btnReturn.setBounds(179, 25, 45, 33);
			panel_2.add(btnReturn);
			
			
			
			//
		table=new JTable();
		table.setModel(db_devis.mytablemodel);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 210, 1178, 426);
		getContentPane().add(scrollPane);
		table.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2)
				{
					new DevisModifier(db_devis.mytablemodel.getDevis((int)db_devis.mytablemodel.getValueAt(table.getSelectedRow(), 0))).setVisible(true);
				}
				
			}
		});
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(SystemColor.textHighlight));
		panel.setBounds(10, 2, 1178, 91);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNouveau = new JButton("Nouveau");
		btnNouveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DevisNouveau(db_devis).setVisible(true);
			}
		});
		btnNouveau.setBounds(2, 6, 123, 80);
		btnNouveau.setBackground(SystemColor.controlHighlight); 
		panel.add(btnNouveau);
		
		JButton btnBonLivraison = new JButton("Bon Livraison");
		btnBonLivraison.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Devis_EnBonLivraison().setVisible(true);
			}
		});
		btnBonLivraison.setBounds(123, 6, 123, 80);
		panel.add(btnBonLivraison);
		this.setVisible(true);

	}
	public void search()
	{
		 s=textRecherche.getText();
			if(cb_Recherche.getSelectedItem().toString().equals("R\u00E9ference"))
			{ req = "SELECT * FROM `devis` WHERE `ref_devis` LIKE '%"+s+"%'";	
			}
			if(cb_Recherche.getSelectedItem().toString().equals("Date"))
			{ req="SELECT devis.* FROM devis,document_vente WHERE devis.id_doc_vente=document_vente.id_documentV AND document_vente.date_documentV LIKE '%"+s+"%'"+" and document_vente.type_doc='D'";
	    		
			}
			if(cb_Recherche.getSelectedItem().toString().equals("Client"))
			{ req="SELECT devis.* FROM devis,document_vente,client WHERE devis.id_doc_vente=document_vente.id_documentV AND document_vente.id_client=client.id_client and client.nom LIKE '%"+s+"%'";
				
			}
			
			rsrech=ConnectionDataBase.executeQuery(req);
			rechercheModel=new DevisModel(rsrech);
			db_devis.mytablemodel=rechercheModel;
			table.setModel(db_devis.mytablemodel);
			//db_article.mytablemodel=rechercheModel;
			//table.setModel(db_article.mytablemodel);
		
		
		
	
	}	
}
