import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import classPack.Article;
import classPack.Client;
import ControlerPack.ArticleBase;
import ControlerPack.ArticleModel;
import ControlerPack.ClientBase;
import ControlerPack.ClientModel;
import ControlerPack.ConnectionDataBase;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class ClientInternalFrame extends JInternalFrame implements MouseListener{

	private JTextField textRecherche;
	private JComboBox<String> cb_Recherche;
	private JTable table;
	private String req,s;
	ResultSet rsrech;
	ClientBase db_client=null;
	private ClientModel rechercehModel;
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientInternalFrame frame = new ClientInternalFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public ClientInternalFrame() {
		setBounds(100, 100, 450, 300);
		    setTitle("Client");
			 db_client=new ClientBase((ResultSet)ConnectionDataBase.executeQuery("select * from client"));
			 this.setBorder(null);
				this.setResizable(true);
				this.setIconifiable(true);
				this.setClosable(true);
				this.setBounds(0, 0, 1198, 685);
				this.setVisible(true);
				
				this.getContentPane().setLayout(null);
				
				 cb_Recherche = new JComboBox<String>();
					cb_Recherche.setModel(new DefaultComboBoxModel(new String[] {"N�cin", "Nom", "Pr�nom", "Adresse", "Ville","N�T�l�phone","E-mail","Matricule Fiscale","N�reglement commercial"}));
					cb_Recherche.setBounds(21, 25, 133, 33);
					
				
					JPanel panel_2 = new JPanel();
					panel_2.setBorder(new TitledBorder(null, "Rechercher", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 191, 255)));
					panel_2.setBounds(10, 85, 1178, 81);
					this.getContentPane().add(panel_2);
					panel_2.setLayout(null);
					panel_2.add(cb_Recherche);
					textRecherche = new JTextField();
					textRecherche.addKeyListener(new KeyAdapter() {
						@Override
						public void keyReleased(KeyEvent e) {
							search();
						}
					});
					textRecherche.setBounds(232, 25, 255, 33);
					panel_2.add(textRecherche);
					textRecherche.setColumns(10);
				
				JButton btnRechercher = new JButton("");
				
				Image imgrecherche=new ImageIcon(this.getClass().getResource("/Recherche.png")).getImage();
				btnRechercher.setIcon(new ImageIcon(imgrecherche));
				btnRechercher.addActionListener(new ActionListener() {
					
					public void actionPerformed(ActionEvent e) {
						search();
					}
					});
				btnRechercher.setBounds(497, 25, 56, 33);
				panel_2.add(btnRechercher);
				
				JButton btnReturn = new JButton("");
				Image imgrefresh=new ImageIcon(this.getClass().getResource("/Refresh.png")).getImage();
				btnReturn.setIcon(new ImageIcon(imgrefresh));
				btnReturn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						
						db_client.cm=new ClientModel(ConnectionDataBase.executeQuery("select *from client"));
						table.setModel(db_client.cm);
					}
				});
				btnReturn.setBounds(179, 25, 45, 33);
				panel_2.add(btnReturn);
				
				
				
				
				table = new JTable();
				
				table.setModel(db_client.cm);
				table.addMouseListener(this);
				
				
				JScrollPane scrollPane = new JScrollPane(table);
				scrollPane.setBounds(10, 171, 1178, 476);
				
		getContentPane().add(scrollPane);
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, Color.CYAN));
		panel.setBounds(10, 2, 1178, 81);
		getContentPane().add(panel);
		panel.setLayout(null);

		JButton bajout = new JButton("Ajouter");
		bajout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClientAjout c=new ClientAjout(db_client);
				c.setVisible(true);
				
			}
		});
		bajout.setBounds(3, 3, 108, 74);
		panel.add(bajout);
		bajout.setBackground(SystemColor.controlHighlight);

		JButton bmodif = new JButton("Modifier");
	bmodif.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(table.isRowSelected(table.getSelectedRow()))
				{
					Client cl= db_client.getClient((int)table.getValueAt(table.getSelectedRow(), 0));
					ClientModifier cm=new ClientModifier(db_client,cl,table.getModel());
					cm.setVisible(true);
				}
				else
				{JOptionPane.showMessageDialog(null,"Il faut selectionner une ligne!","Erreur",JOptionPane.ERROR_MESSAGE);}
				
			}
		});
		bmodif.setBounds(108, 3, 108, 74);
		panel.add(bmodif);
		bmodif.setBackground(SystemColor.controlHighlight);

		JButton bsup = new JButton("Supprimer");
		bsup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(table.isRowSelected(table.getSelectedRow()))
				{
					
					db_client.supprimerClient((int)table.getModel().getValueAt(table.getSelectedRow(), 0) );
				}
				else
				{JOptionPane.showMessageDialog(null,"Il faut selectionner une ligne!","Erreur",JOptionPane.ERROR_MESSAGE);}
			}
			
		});



		bsup.setBounds(214, 3, 108, 74);
		panel.add(bsup);
		bsup.setBackground(SystemColor.controlHighlight);

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2){
					Client cl= db_client.getClient((int)table.getModel().getValueAt(table.getSelectedRow(), 0));
					ClientModifier cm=new ClientModifier(db_client,cl,table.getModel());
					cm.setVisible(true);
					
				}
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			public void search()
			{
				 s=textRecherche.getText();
					if(cb_Recherche.getSelectedItem().toString().equals("N�cin"))
					{ req = "select * from client where ncin LIKE '%"+s+"%'";	
					}
					if(cb_Recherche.getSelectedItem().toString().equals("Nom"))
					{ req = "select * from client where nom LIKE '%"+s+"%'";
						
					}
					if(cb_Recherche.getSelectedItem().toString().equals("Pr�nom"))
					{ req = "select * from client where prenom LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("Adresse"))
					{ req = "select * from client where  adresse LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("Ville"))
					{ req = "select * from client where  ville LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("N�T�l�phone"))
					{ req = "select * from client where  tel LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("E-mail"))
					{ req = "select * from client where  email LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("Matricule Fiscale"))
					{ req = "select * from client where  matricule_fiscale LIKE '%"+s+"%'";
					}
					if(cb_Recherche.getSelectedItem().toString().equals("N�reglement commercial"))
					{ req = "select * from client where  num_reg_commercial LIKE '%"+s+"%'";
					}
					rsrech=ConnectionDataBase.executeQuery(req);
					rechercehModel=new ClientModel(rsrech);
					
					db_client.cm=rechercehModel;
					table.setModel(db_client.cm);
				
				
				
			
			}	
		}
