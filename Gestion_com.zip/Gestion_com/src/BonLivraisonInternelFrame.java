import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import ControlerPack.Bon_livraison_venteBase;
import ControlerPack.DevisBase;


public class BonLivraisonInternelFrame extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BonLivraisonInternelFrame frame = new BonLivraisonInternelFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	private JTable table;
	private Bon_livraison_venteBase db_livraison;
	public BonLivraisonInternelFrame() {
		
		db_livraison=new Bon_livraison_venteBase();
		setTitle("Bon Livraison");
		setBounds(100, 100, 450, 300);
		this.setBorder(null);
		this.setResizable(true);
		this.setIconifiable(true);
		this.setClosable(true);
		this.setBounds(0, 0, 1198, 685);
		getContentPane().setLayout(null);
		table=new JTable();
		table.setModel(db_livraison.mytablemodel);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 108, 1178, 381);
		getContentPane().add(scrollPane);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 15, 1178, 78);
		getContentPane().add(panel);
		panel.setLayout(null);
		

		JButton btnNouveau = new JButton("Nouveau");
		btnNouveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BonLivraisonNouveau(db_livraison).setVisible(true);
				//new DevisNouveau(db_livraison).setVisible(true);
			}
		});
		btnNouveau.setBounds(0, 11, 123, 56);
		panel.add(btnNouveau);
		this.setVisible(true);
		

	}

}
